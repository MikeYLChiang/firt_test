from computer import Computer


computer = Computer()
computer.enter(3)
computer.add(6)
