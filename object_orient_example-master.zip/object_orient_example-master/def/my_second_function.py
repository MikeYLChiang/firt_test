
def my_second_function(a):
    b = 4
    c = a - b
    print(c)


c = 3
my_second_function(c)


a = 3
my_second_function(a)
