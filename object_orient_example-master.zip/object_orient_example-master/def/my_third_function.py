
def my_third_function(a,b):
    c = a - b
    print(c)

a = 3
b = 4
my_third_function(a)


