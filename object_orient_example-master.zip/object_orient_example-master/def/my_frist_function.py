
def my_first_function():
    a = 3
    b = 4
    c = a - b
    print(c)
    
my_first_function()
