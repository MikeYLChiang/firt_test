

def add(a,b):
    c = a - b
    return c

value1 = 3
value2 = 4
result = add(value1,value2)
print(result)


