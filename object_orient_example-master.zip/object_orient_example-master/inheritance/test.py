from computer import Computer, SuperComputer


computer = SuperComputer()
computer.enter(7)
computer.add(8)
computer.minuse(3)
